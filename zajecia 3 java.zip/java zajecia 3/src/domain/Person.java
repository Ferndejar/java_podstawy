package domain;

public class Person {
	private char Name;
	private char Surname;
	private int Age;
	
	
	public Person(char Name,char Surname,int Age) {
		// TODO Auto-generated constructor stub
		this.Name = Name;
		this.Surname= Surname;
		this.Age = Age;
	}
	
	public void setAge(int Age)
	{
		this.Age = Age;
	}
	
	public void setName(char Name)
	{
		this.Name = Name;
	}
	
	public void setSurname(char Surname)
	{
		this.Surname = Surname;
	}
	
	public int getAge()
	{
		return Age;
	}
	
	public char getName()
	{
		return Name;
	}
	
	public char getSurname()
	{
		return Surname;
	}
	
	
	
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	}

}
